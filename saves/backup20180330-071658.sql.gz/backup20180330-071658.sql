--
-- backup20180330-071658.sql.gz


DROP TABLE IF EXISTS `association_table`;
CREATE TABLE `association_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_doc` int(11) NOT NULL,
  `id_baseline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_doc` (`id_doc`),
  KEY `id_baseline` (`id_baseline`),
  KEY `id_doc_2` (`id_doc`),
  KEY `id_baseline_2` (`id_baseline`),
  CONSTRAINT `FK_id_baseline` FOREIGN KEY (`id_baseline`) REFERENCES `gatc_baseline` (`id_baseline`),
  CONSTRAINT `FK_id_doc` FOREIGN KEY (`id_doc`) REFERENCES `document` (`id_doc`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `association_table` VALUES ('2','2','2');
INSERT INTO `association_table` VALUES ('3','3','1');
INSERT INTO `association_table` VALUES ('5','6','1');
INSERT INTO `association_table` VALUES ('6','1','2');


DROP TABLE IF EXISTS `document`;
CREATE TABLE `document` (
  `id_doc` int(11) NOT NULL AUTO_INCREMENT,
  `id_document_language` int(11) NOT NULL,
  `id_document_version` int(11) NOT NULL,
  `id_document_reference` int(11) NOT NULL,
  PRIMARY KEY (`id_doc`),
  KEY `id_document_language` (`id_document_language`),
  KEY `id_document_version` (`id_document_version`),
  KEY `id_document_reference` (`id_document_reference`),
  CONSTRAINT `FK_id_document_language` FOREIGN KEY (`id_document_language`) REFERENCES `document_language` (`id_entry`),
  CONSTRAINT `FK_id_document_reference` FOREIGN KEY (`id_document_reference`) REFERENCES `document_reference` (`id_ref`),
  CONSTRAINT `FK_id_document_version` FOREIGN KEY (`id_document_version`) REFERENCES `document_version` (`id_version`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `document` VALUES ('1','1','1','1');
INSERT INTO `document` VALUES ('2','2','1','1');
INSERT INTO `document` VALUES ('3','3','2','2');
INSERT INTO `document` VALUES ('6','2','2','2');


DROP TABLE IF EXISTS `document_language`;
CREATE TABLE `document_language` (
  `id_entry` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(60) NOT NULL,
  `project` varchar(60) NOT NULL,
  `translator` varchar(60) NOT NULL,
  PRIMARY KEY (`id_entry`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `document_language` VALUES ('1','FR','Umbrella','Med');
INSERT INTO `document_language` VALUES ('2','EN','Sunshine','Lambert');
INSERT INTO `document_language` VALUES ('3','NL','Mitsui','M. Dupont');


DROP TABLE IF EXISTS `document_reference`;
CREATE TABLE `document_reference` (
  `id_ref` int(11) NOT NULL DEFAULT '0',
  `reference` char(255) NOT NULL DEFAULT 'To be defined',
  `subject` char(255) NOT NULL DEFAULT 'To be defined',
  `initial_language` char(2) NOT NULL DEFAULT 'EN',
  `previous_doc` char(255) NOT NULL,
  `product` char(10) NOT NULL,
  `component` char(40) NOT NULL,
  `installation` tinyint(1) NOT NULL DEFAULT '0',
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `x_link` char(255) NOT NULL,
  `aec_link` char(255) NOT NULL,
  `ftp_link` char(255) NOT NULL,
  `sharepoint_vbn_link` char(255) NOT NULL,
  `sharepoint_blq_link` char(255) NOT NULL,
  `different_AEC` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_ref`),
  KEY `product` (`product`),
  KEY `component` (`component`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `document_reference` VALUES ('1','4RDUKP5396','TRAINBORNE MAINTENANCE BOX - MANUEL UTILISATEUR','EN','','Tools','ODE','0','1','','','','','','0');
INSERT INTO `document_reference` VALUES ('2','5.0300.091','TRU SEHERON TELOC 1550 SYSTEM DESCRIPTION','DE','','TRU','TELOC 1550','1','0','','','','','','0');


DROP TABLE IF EXISTS `document_version`;
CREATE TABLE `document_version` (
  `id_version` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(10) NOT NULL DEFAULT 'tbd',
  `site` varchar(3) NOT NULL,
  `pic` varchar(60) NOT NULL,
  `availability_x` tinyint(1) NOT NULL DEFAULT '0',
  `availability_aec` tinyint(1) NOT NULL DEFAULT '0',
  `availability_ftp` tinyint(1) NOT NULL DEFAULT '0',
  `availability_sharepoint_vbn` tinyint(1) NOT NULL DEFAULT '0',
  `availability_sharepoint_blq` tinyint(1) NOT NULL DEFAULT '0',
  `remarks` varchar(100) NOT NULL DEFAULT 'peupl� par d�faut',
  `working_field_1` char(20) NOT NULL,
  `working_field_2` char(20) NOT NULL,
  `working_field_3` char(20) NOT NULL,
  `working_field_4` char(20) NOT NULL,
  `status` enum('Public','Internal','Draft','Future','Obsolete') NOT NULL DEFAULT 'Draft',
  PRIMARY KEY (`id_version`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `document_version` VALUES ('1','A01','VBN','M. Dem.','0','0','0','0','0','peupl� par d�faut','uh','meh','','','Public');
INSERT INTO `document_version` VALUES ('2','10.2C','CRL','C. Bac.','0','0','0','0','0','Needs to be reviewed','Working','field','','','Draft');


DROP TABLE IF EXISTS `gatc_baseline`;
CREATE TABLE `gatc_baseline` (
  `id_baseline` int(11) NOT NULL AUTO_INCREMENT,
  `GATC_baseline` char(20) NOT NULL,
  `UNISIG_baseline` char(20) NOT NULL,
  PRIMARY KEY (`id_baseline`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `gatc_baseline` VALUES ('1','5.6.0','2');
INSERT INTO `gatc_baseline` VALUES ('2','5.7.0','2');


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `last_name` char(50) NOT NULL,
  `first_name` char(30) NOT NULL,
  `password` char(20) NOT NULL DEFAULT 'Alstom$Gest',
  `status` enum('Internal','External','Manager','Administrator','Forbidden') NOT NULL DEFAULT 'External',
  `language` char(2) NOT NULL DEFAULT 'EN',
  `isConnected` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `users` VALUES ('1','test','test','test','Administrator','FR','1');
INSERT INTO `users` VALUES ('5','forbidden','forbidden','forbidden','Forbidden','EN','0');
INSERT INTO `users` VALUES ('6','external','external','external','External','EN','0');
INSERT INTO `users` VALUES ('8','manager1','manager1','manager1','Manager','FR','0');
INSERT INTO `users` VALUES ('10','manager2','manager2','manager2','Manager','EN','0');
INSERT INTO `users` VALUES ('11','internal','internal','internal','Internal','EN','0');
INSERT INTO `users` VALUES ('12','test2','test2','test2','Manager','FR','0');
